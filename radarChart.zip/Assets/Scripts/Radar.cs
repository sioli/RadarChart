﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace com.tencent.pandora
{
    [AddComponentMenu("UI/Radar", 150)]
    public class Radar : MaskableGraphic
    {
        #region Inspector 显示项
        [Range(3, 10)]
        [SerializeField] private int _sideCount = 5;

        [SerializeField] private float _size = 100;

        [Range(0, 360)]
        [SerializeField] private float _rotation = 0;

        [Range(0, 1)]
        [SerializeField] private float[] _vertexToCenterDistances;

        [SerializeField] private ShowProperty _showProperty = new ShowProperty(true, false, false, false);

        [SerializeField] private FillProperty _fillProperty = new FillProperty();

        [SerializeField] private WireFrameProperty _wireFrameProperty = new WireFrameProperty();

        [SerializeField] private BorderProperty _borderProperty = new BorderProperty();

        [SerializeField] private CornerProperty _cornerProperty = new CornerProperty();

        //用于判断是否改动了_size或_rotation，然后用于同步RectTransform的值
        private float _lastSize;
        private float _lastRotation;

        #endregion

        //设置某个顶点到中心的距离,对外暴露接口
        public void SetVertexToCenterDistance(int index, float distance)
        {
            if (index < 0 || index > _vertexToCenterDistances.Length - 1)
            {
                Debug.LogError(string.Format("SetVertexToCenterDistance 参数index非法，index 可访问范围为0-{0}，当前index 为{1},请纠正。", _vertexToCenterDistances.Length - 1, index));
                return;
            }

            if (distance < 0 || distance > 1)
            {
                Debug.LogError(string.Format("distance 必须在[0,1]范围内，当前distance 为{0},请检查！", distance));
                return;
            }

            _vertexToCenterDistances[index] = distance;
            SetVerticesDirty();
        }

        public override Texture mainTexture
        {
            get
            {
                if (_showProperty.fill == false)
                {
                    return base.mainTexture;
                }
                //优先使用材质中的贴图
                if (_fillProperty.material != null && _fillProperty.material.mainTexture != null)
                {
                    return _fillProperty.material.mainTexture;
                }

                if (_fillProperty.texture != null)
                {
                    return _fillProperty.texture;
                }

                return base.mainTexture;
            }
        }

        private void RefreshVertexDistance()
        {
            if (_vertexToCenterDistances == null)
            {
                _vertexToCenterDistances = new float[_sideCount];
                for (int i = 0; i < _sideCount; i++)
                {
                    _vertexToCenterDistances[i] = 1f;
                }
                return;
            }

            int preLength = _vertexToCenterDistances.Length;
            int currentLength = _sideCount;
            float[] currentDistances = new float[currentLength];
            int minLength = Mathf.Min(preLength, currentLength);
            for (int i = 0; i < minLength; i++)
            {
                currentDistances[i] = _vertexToCenterDistances[i];
            }

            if (currentLength > minLength)
            {
                for (int j = preLength; j < currentLength; j++)
                {
                    currentDistances[j] = 1;
                }
            }
            _vertexToCenterDistances = currentDistances;
            return;
        }

        protected override void OnPopulateMesh(VertexHelper vertexHelper)
        {
            RefreshSize();
            RefreshRotation();
            if (_vertexToCenterDistances.Length != _sideCount)
            {
                RefreshVertexDistance();
            }
            vertexHelper.Clear();

            if (_showProperty.fill == true)
            {
                PopulateFillMesh(vertexHelper);
            }

            if (_showProperty.showWireFrame == true)
            {
                PopulateWireFrameMesh(vertexHelper);
            }

            if (_showProperty.showBorder == true)
            {
                PopulateBorderMesh(vertexHelper);
            }

            if (_showProperty.showCorner == true)
            {
                PopulateCornerMesh(vertexHelper);
            }
        }

        private void PopulateFillMesh(VertexHelper vertexHelper)
        {
            PopulateFillMesh(vertexHelper, Vector2.zero, _size, _sideCount, _fillProperty.color);
        }

        //填充模式和显示角点都会用到此函数
        private void PopulateFillMesh(VertexHelper vertexHelper, Vector2 center, float radius, int sideCount, Color color, bool needScale = true)
        {
            List<Vector2> vertexPositionList = GetVertexPositionList(center, radius, sideCount, needScale);
            vertexPositionList.Add(center);//添加中心点坐标

            for (int i = 0; i < sideCount; i++)
            {
                Vector2 position1 = vertexPositionList[i];
                Vector2 position2 = vertexPositionList[sideCount + 1];
                Vector2 position3 = vertexPositionList[sideCount + 1];
                Vector2 position4 = vertexPositionList[i + 1];

                Vector2[] positionArray = new Vector2[] { position1, position2, position3, position4 };
                Vector2[] uvArray = new Vector2[] { GenerateUVCoordinate(position1), GenerateUVCoordinate(position2), GenerateUVCoordinate(position3), GenerateUVCoordinate(position4) };
                UIVertex[] vertexArray = GenerateQuadVertexArray(positionArray, color, uvArray);
                vertexHelper.AddUIVertexQuad(vertexArray);
            }
        }

        //获取多边形顶点的位置列表
        private List<Vector2> GetVertexPositionList(Vector2 center, float radius, int sideCount, bool needScale = true)
        {
            List<Vector2> positionList = new List<Vector2>(sideCount + 1);
            float sliceDegree = 360 / sideCount;
            for (int i = 0; i < sideCount; i++)
            {
                Vector2 position = new Vector2();
                float currentRadian = Mathf.Deg2Rad * i * sliceDegree;
                float scale = needScale ? _vertexToCenterDistances[i] : 1;
                position.x = radius * scale * Mathf.Cos(currentRadian);
                position.y = radius * scale * Mathf.Sin(currentRadian);
                position += center;
                positionList.Add(position);
            }
            positionList.Add(positionList[0]);//添加一个和第一个顶点重合的点，方便索引
            return positionList;
        }

        //计算顶点的uv坐标
        private Vector2 GenerateUVCoordinate(Vector2 position)
        {
            Vector2 uv = (position + new Vector2(_size, _size)) / (2 * _size);
            return uv;
        }

        //线框 
        private void PopulateWireFrameMesh(VertexHelper vertexHelper)
        {
            List<Vector2> vertexPositionList = GetVertexPositionList(Vector2.zero, _size, _sideCount);
            vertexPositionList.Add(Vector2.zero);
            Color color = _wireFrameProperty.color;

            for (int i = 0; i < _sideCount; i++)
            {
                Vector2 directionVecotr1 = vertexPositionList[i + 1] - vertexPositionList[i];
                Vector2 offset1 = GetNormalizedVerticalVector(directionVecotr1) * _wireFrameProperty.thickness;
                Vector2 pos1 = vertexPositionList[i] - offset1;
                Vector2 pos2 = vertexPositionList[i + 1] - offset1;
                Vector2 pos3 = vertexPositionList[i + 1] + offset1;
                Vector2 pos4 = vertexPositionList[i] + offset1;

                Vector2 directionVecotr2 = vertexPositionList[_sideCount + 1] - vertexPositionList[i];
                Vector2 offset2 = GetNormalizedVerticalVector(directionVecotr2) * _wireFrameProperty.thickness;
                Vector2 pos5 = vertexPositionList[i] - offset2;
                Vector2 pos6 = vertexPositionList[_sideCount + 1] - offset2;
                Vector2 pos7 = vertexPositionList[_sideCount + 1] + offset2;
                Vector2 pos8 = vertexPositionList[i] + offset2;

                UIVertex[] vertexArray1 = GenerateQuadVertexArray(new Vector2[] { pos1, pos2, pos3, pos4 }, color);
                UIVertex[] vertexArray2 = GenerateQuadVertexArray(new Vector2[] { pos5, pos6, pos7, pos8 }, color);
                vertexHelper.AddUIVertexQuad(vertexArray1);
                vertexHelper.AddUIVertexQuad(vertexArray2);
            }
        }

        //获取方向向量的单位垂直向量
        private Vector2 GetNormalizedVerticalVector(Vector2 directionVector)
        {
            float x;
            float y;
            if (directionVector.y == 0)
            {
                x = 0;
                y = 1;
            }
            else
            {
                x = 1;
                y = -(directionVector.x / directionVector.y);
            }

            float length = Mathf.Sqrt(x * x + y * y);
            return new Vector2(x / length, y / length);
        }

        private UIVertex[] GenerateQuadVertexArray(Vector2[] vertices, Color color, Vector2[] uvs = null)
        {
            UIVertex[] vertexArray = new UIVertex[4];
            for (int i = 0; i < 4; i++)
            {
                UIVertex vertex = UIVertex.simpleVert;
                vertex.color = color;
                vertex.position = vertices[i];
                if (uvs != null)
                {
                    vertex.uv0 = uvs[i];
                }
                vertexArray[i] = vertex;
            }
            return vertexArray;
        }

        //边框
        private void PopulateBorderMesh(VertexHelper vertexHelper)
        {
            List<Vector2> inner = GetVertexPositionList(Vector2.zero, _size, _sideCount);
            List<Vector2> outer = GetVertexPositionList(Vector2.zero, _size + _borderProperty.thickness, _sideCount);
            Color color = _borderProperty.color;

            for (int i = 0; i < _sideCount; i++)
            {
                Vector2[] positionArray = new Vector2[] { inner[i], inner[i + 1], outer[i + 1], outer[i] };
                UIVertex[] vertexArray = GenerateQuadVertexArray(positionArray, color);
                vertexHelper.AddUIVertexQuad(vertexArray);
            }
        }

        //顶点
        private void PopulateCornerMesh(VertexHelper vertexHelper)
        {
            List<Vector2> vertexPositionList = GetVertexPositionList(Vector2.zero, _size, _sideCount);
            for (int i = 0; i < _sideCount; i++)
            {
                PopulateFillMesh(vertexHelper, vertexPositionList[i], _cornerProperty.size, _cornerProperty.smoothness, _cornerProperty.color, false);
            }
        }

        protected override void Awake()
        {
            RefreshVertexDistance();
        }

        protected override void OnEnable()
        {
            _size = Mathf.Max(rectTransform.sizeDelta.x, rectTransform.sizeDelta.y);
            _rotation = rectTransform.rotation.eulerAngles.z;
            _lastSize = _size;
            _lastRotation = _rotation;
            //促使立即绘制
            SetVerticesDirty();
            SetMaterialDirty();
        }

        private void RefreshSize()
        {
            float sizeFromRectTransform = Mathf.Max(rectTransform.sizeDelta.x, rectTransform.sizeDelta.y);
            if (_size == sizeFromRectTransform)
            {
                return;
            }

            if (_size != _lastSize)
            {
                rectTransform.sizeDelta = new Vector2(_size, _size);
            }
            else
            {
                _size = Mathf.Max(rectTransform.sizeDelta.x, rectTransform.sizeDelta.y);
            }

            _lastSize = _size;
        }

        private void RefreshRotation()
        {
            float rotationFromRectTransform = rectTransform.rotation.eulerAngles.z;
            if (_rotation == rotationFromRectTransform)
            {
                return;
            }

            if (_rotation != _lastRotation)
            {
                rectTransform.rotation = Quaternion.Euler(0, 0, _rotation);
            }
            else
            {
                _rotation = rectTransform.rotation.eulerAngles.z;
            }

            _lastRotation = _rotation;
        }

        #region 私有类
        //下面的类只是内部使用，不必担心数据被意外更改，变量定义为公有
        [System.Serializable]
        private struct ShowProperty
        {
            public bool fill;
            public bool showWireFrame;
            public bool showBorder;
            public bool showCorner;

            public ShowProperty(bool fill, bool showWireFrame, bool showBorder, bool showVertex)
            {
                this.fill = fill;
                this.showWireFrame = showWireFrame;
                this.showBorder = showBorder;
                this.showCorner = showVertex;
            }
        }

        [System.Serializable]
        private class FillProperty
        {
            public Color color;
            public Texture texture;
            public Material material;

            public FillProperty()
            {
                color = Color.white;
                texture = null;
                material = null;
            }
        }

        [System.Serializable]
        private class WireFrameProperty
        {
            public Color color;
            [Range(0.4f, 1.5f)]
            public float thickness;

            public WireFrameProperty()
            {
                color = Color.red;
                thickness = 0.5f;
            }
        }

        [System.Serializable]
        private class BorderProperty
        {
            public Color color;
            [Range(1, 50)]
            public float thickness;

            public BorderProperty()
            {
                color = Color.green;
                thickness = 3;
            }
        }

        [System.Serializable]
        private class CornerProperty
        {
            public Color color;
            [Range(1, 50)]
            public float size;
            [Range(3, 30)]
            public int smoothness;

            public CornerProperty()
            {
                color = Color.blue;
                size = 3;
                smoothness = 10;
            }
        }
        #endregion
    }
}