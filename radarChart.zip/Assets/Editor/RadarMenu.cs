﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.SceneManagement;

namespace com.tencent.pandora
{
    static public class RadarMenu
    {
        private static Vector2 SIZE = new Vector2(100, 100);

        [MenuItem("GameObject/UI/Radar", false, 2101)]
        private static void AddRadar(MenuCommand menuCommand)
        {
            GameObject radar = CreateRadar();
            PlaceRadar(radar, menuCommand);
        }

        //当返回false时，菜单项没有变灰，但是点击后是不执行的，这个地方可能是GameObject菜单的显示问题
        [MenuItem("GameObject/UI/Radar", true, 2101)]
        private static bool IsChildOfCanvas(MenuCommand menuCommand)
        {
            GameObject selectedGo = menuCommand.context as GameObject;
            Canvas canvas = (selectedGo != null) ? selectedGo.GetComponentInParent<Canvas>() : null;
            return canvas != null ? true : false;
        }

        private static GameObject CreateRadar()
        {
            GameObject radar = new GameObject("Radar");
            RectTransform rectTransform = radar.AddComponent<RectTransform>();
            rectTransform.sizeDelta = SIZE;
            radar.AddComponent<Radar>();
            return radar;
        }

        private static void PlaceRadar(GameObject radar, MenuCommand menuCommand)
        {
            GameObject parent = menuCommand.context as GameObject;
            SceneManager.MoveGameObjectToScene(radar, parent.scene);
            radar.name = GameObjectUtility.GetUniqueNameForSibling(parent.transform, radar.name);
            //注册undo
            Undo.RegisterCreatedObjectUndo(radar, "Create " + radar.name);
            Undo.SetTransformParent(radar.transform, parent.transform, "Parent " + radar.name);
            Undo.SetCurrentGroupName("Create " + radar.name);

            GameObjectUtility.SetParentAndAlign(radar, parent);
            Selection.activeGameObject = radar;
        }
    }
}