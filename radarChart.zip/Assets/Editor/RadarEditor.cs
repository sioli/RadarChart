﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace com.tencent.pandora
{
    [CustomEditor(typeof(Radar))]
    [CanEditMultipleObjects]
    public class RadarEditor : Editor
    {
        private SerializedProperty _sideCount;
        private SerializedProperty _size;
        private SerializedProperty _rotation;
        private SerializedProperty _vertexToCenterDistances;
        private SerializedProperty _showProperty;
        private SerializedProperty _fillProperty;
        private SerializedProperty _wireFrameProperty;
        private SerializedProperty _borderProperty;
        private SerializedProperty _cornerProperty;

        private void OnEnable()
        {
            _sideCount = serializedObject.FindProperty("_sideCount");
            _size = serializedObject.FindProperty("_size");
            _rotation = serializedObject.FindProperty("_rotation");
            _vertexToCenterDistances = serializedObject.FindProperty("_vertexToCenterDistances");
            _showProperty = serializedObject.FindProperty("_showProperty");
            _fillProperty = serializedObject.FindProperty("_fillProperty");
            _wireFrameProperty = serializedObject.FindProperty("_wireFrameProperty");
            _borderProperty = serializedObject.FindProperty("_borderProperty");
            _cornerProperty = serializedObject.FindProperty("_cornerProperty");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            GeneralControlsGUI();
            ShowControlsGUI();
            FillControlsGUI();
            WireFrameControlsGUI();
            BorderControlsGUI();
            CornerControlsGUI();
            serializedObject.ApplyModifiedProperties();
        }

        private void GeneralControlsGUI()
        {
            EditorGUILayout.LabelField(EditorGUIUtility.TrTextContent("通用设置", "设置雷达图外观的基本参数"));
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(_sideCount);
            EditorGUILayout.PropertyField(_size);
            EditorGUILayout.PropertyField(_rotation);
            if (EditorGUILayout.PropertyField(_vertexToCenterDistances))
            {
                EditorGUI.indentLevel++;
                for (int i = 0; i < _vertexToCenterDistances.arraySize; i++)
                {
                    EditorGUILayout.PropertyField(_vertexToCenterDistances.GetArrayElementAtIndex(i));
                }
                EditorGUI.indentLevel--;
            }
            EditorGUI.indentLevel--;
            EditorGUILayout.Separator();
        }

        private void ShowControlsGUI()
        {
            EditorGUILayout.LabelField(EditorGUIUtility.TrTextContent("外观显示设置", "控制雷达图的显示方式"));
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(_showProperty.FindPropertyRelative("fill"));
            EditorGUILayout.PropertyField(_showProperty.FindPropertyRelative("showWireFrame"));
            EditorGUILayout.PropertyField(_showProperty.FindPropertyRelative("showBorder"));
            EditorGUILayout.PropertyField(_showProperty.FindPropertyRelative("showCorner"));
            EditorGUI.indentLevel--;
            EditorGUILayout.Separator();
        }

        private void FillControlsGUI()
        {
            EditorGUILayout.LabelField(EditorGUIUtility.TrTextContent("填充模式设置", "设置显示模式为填充时的属性"));
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(_fillProperty.FindPropertyRelative("color"));
            EditorGUILayout.PropertyField(_fillProperty.FindPropertyRelative("texture"));
            EditorGUILayout.PropertyField(_fillProperty.FindPropertyRelative("material"));
            EditorGUI.indentLevel--;
            EditorGUILayout.Separator();
        }

        private void WireFrameControlsGUI()
        {
            EditorGUILayout.LabelField(EditorGUIUtility.TrTextContent("线框模式设置", "设置显示模式为线框时的属性"));
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(_wireFrameProperty.FindPropertyRelative("color"));
            EditorGUILayout.PropertyField(_wireFrameProperty.FindPropertyRelative("thickness"));
            EditorGUI.indentLevel--;
            EditorGUILayout.Separator();
        }

        private void BorderControlsGUI()
        {
            EditorGUILayout.LabelField(EditorGUIUtility.TrTextContent("边模式设置", "设置显示模式为边时的属性"));
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(_borderProperty.FindPropertyRelative("color"));
            EditorGUILayout.PropertyField(_borderProperty.FindPropertyRelative("thickness"));
            EditorGUI.indentLevel--;
            EditorGUILayout.Separator();
        }

        private void CornerControlsGUI()
        {
            EditorGUILayout.LabelField(EditorGUIUtility.TrTextContent("顶点模式设置", "设置显示模式为顶点时的属性"));
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(_cornerProperty.FindPropertyRelative("color"));
            EditorGUILayout.PropertyField(_cornerProperty.FindPropertyRelative("size"));
            EditorGUILayout.PropertyField(_cornerProperty.FindPropertyRelative("smoothness"));
            EditorGUI.indentLevel--;
            EditorGUILayout.Separator();
        }
    }
}